package masalaMoneyBox;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masalaMoneyBox
 * Class Name -> Money
 * Copyright © : 9/5/2022
 */
public class Money {
    int price;

    public Money(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }
}

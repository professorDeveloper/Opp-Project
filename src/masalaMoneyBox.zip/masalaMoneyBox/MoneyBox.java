package masalaMoneyBox;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masalaMoneyBox
 * Class Name -> MoneyBox
 * Copyright © : 9/5/2022
 */
public class MoneyBox {
    int counts;
    Money[] moneyList;
    private int countMoney;
    private int allMoneySize;

    public MoneyBox(int counts) {
        this.counts = counts;
        moneyList = new Money[counts];
    }

    public void addMoney(Money money) {
        if (countMoney<=counts) {
            moneyList[countMoney++] = money;
            allMoneySize += money.getPrice();
            System.out.println("Added Money");
        }else {
            System.out.println("Not Added Money");
        }
    }

    public boolean isEmpty(){
        return moneyList.length==0;
    }
    public boolean isFully(){
        return moneyList.length==counts;
    }
    public int getMoneyCount (){
        return countMoney;
    }
    public int getAmount(){
        return allMoneySize;
    }

}

package homework14;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> homework14
 * Class Name ->
 * Copyright © : 9/15/2022
 */
interface MessageInterface  {
    void showMessage(String message);
}

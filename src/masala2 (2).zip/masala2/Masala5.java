package masala2;

import java.util.Scanner;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masala2
 * Class Name -> Masala5
 * Copyright © : 8/24/2022
 */
public class Masala5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char s = 'a';
        char s1 = 'A';
        System.out.println((int) s);
        System.out.println((int) s1);
        System.out.println(kattaKichik("hello", "HELLO"));
    }

    public static String kattaKichik(String str1, String str2) {
        boolean mavjud = false;
        for (int i = 0; i < str1.length(); i++) {
            if (str1.charAt(i) - 32 == str2.charAt(i) && str1.trim().length() == str2.trim().length()) {
                mavjud = true;
            } else {
                mavjud = false;
            }
        }
        if (mavjud) {
        return "Ha";
        }else {
          return   "Yo`q";
        }
    }
}

package masala2;

import java.util.Scanner;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masala2
 * Class Name -> Masala2
 * Copyright © : 8/23/2022
 */
public class Masala2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("birinchi so`z:");
        String a = scanner.nextLine();
        System.out.println("Ikkinchi so`z");
        String b = scanner.nextLine();
        String s =remVowel(a);
        String s1 =remVowel(b);
        if (s.equalsIgnoreCase(s1)){
            System.out.println("Bir xil");
        }else {
            System.out.println("Xar Xil");
        }
    }
    static String remVowel(String str)
    {
        return str.replaceAll("[aeiouAEIOU]", "");
    }
}

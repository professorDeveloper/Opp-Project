package masalaMoneyBox;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masalaMoneyBox
 * Class Name -> main
 * Copyright © : 9/5/2022
 */
public class Main {
    public static void main(String[] args) {
        MoneyBox moneyBox=new MoneyBox(8);
        Money money=new Money(10);
        Money money2=new Money(20);
        Money money3=new Money(30);
        Money money4=new Money(40);
        Money money5=new Money(50);
        Money money6=new Money(60);
        Money money7=new Money(70);
        Money money8=new Money(80);
        System.out.println(moneyBox.isEmpty());
        System.out.println(moneyBox.isFully());
        moneyBox.addMoney(money);
        moneyBox.addMoney(money2);
        moneyBox.addMoney(money3);
        moneyBox.addMoney(money4);
        moneyBox.addMoney(money5);
        moneyBox.addMoney(money6);
        moneyBox.addMoney(money7);
        moneyBox.addMoney(money8);
        System.out.println(moneyBox.getAmount());
        System.out.println(moneyBox.isFully());
        moneyBox.addMoney(money);
    }
}

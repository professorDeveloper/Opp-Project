package homework13;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> homework13
 * Class Name -> Main
 * Copyright © : 9/14/2022
 */
public class Main {
    public static void main(String[] args) {
     User user=new User.UserBuilder("+998992803809",1234).build();
        System.out.println(user.getPhone());
        System.out.println(user.getCode());


    }
}

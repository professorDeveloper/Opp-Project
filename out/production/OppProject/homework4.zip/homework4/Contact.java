package homework4;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> homework4
 * Class Name -> Contact
 * Copyright © : 8/26/2022
 */
public class Contact {
    String name;
    String number;
    String imgUrl;
    void Show(){
        System.out.println("Contact name: "+name);
        System.out.println("Contact number: "+number);
        System.out.println("Contact imgUrl: "+imgUrl);
    }
}

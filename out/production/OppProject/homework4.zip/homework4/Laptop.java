package homework4;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> homework4
 * Class Name -> Laptop
 * Copyright © : 8/26/2022
 */
public class Laptop {
    int screenSize;
    int battaryCellCount;
    String modelName;
    int serialNumber;
    String color;

}

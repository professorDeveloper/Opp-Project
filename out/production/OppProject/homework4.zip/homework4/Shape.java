package homework4;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> homework4
 * Class Name -> Shape
 * Copyright © : 8/26/2022
 */
public class Shape {
    String color;
    int perimeter;
    int square;
    void show(){
        System.out.println("Shape Color:"+color);
        System.out.println("Shape Perimeter:"+perimeter);
        System.out.println("Shape Square:"+square);
    }
    void  showPerimeter(){
        System.out.println("Perimeter: "+perimeter);
    }
}

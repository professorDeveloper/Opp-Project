package homework4;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> student
 * Class Name -> Student
 * Copyright © : 8/26/2022
 */
public class Student {
    String name;
    int course;
    int age;
    public  Student(String _name, int _course, int _age) {
        name = _name;
        course = _course;
        age = _age;
    }
    void Info(){
        System.out.println("Student Name: "+name);
        System.out.println("Student course: "+course);
        System.out.println("Student age: "+age);
    }
}

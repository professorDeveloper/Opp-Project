package homework4;

import java.util.Arrays;
/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> student
 * Class Name -> Main
 * Copyright © : 8/26/2022
 */
public class Task4 {
    public static void main(String[] args) {

        System.out.println("=============================================================");
        Student student = new Student("Husanboy",1,16);
        student.Info();
        System.out.println("=============================================================");

        Shape shape = new Shape();
        shape.perimeter = 10;
        shape.square = 20;
        shape.color = "Black";
        shape.show();

        System.out.println("=============================================================");

        shape.showPerimeter();

        System.out.println("=============================================================");

        Contact contact = new Contact();
        contact.name = "Husanboy";
        contact.number = "+998943017410";
        contact.imgUrl = "https://assets.leetcode.com/users/avatars/avatar_1661248124.png";
        contact.Show();

        System.out.println("=============================================================");
        Laptop laptop = new Laptop();
        laptop.color = "Serious Black";
        laptop.battaryCellCount = 3000;
        laptop.modelName = "Acer";
        laptop.screenSize = 1090;
        laptop.serialNumber = 1200;
        System.out.println("Laptop Name:" + laptop.modelName);
        System.out.println("Laptop Color:" + laptop.color);
        System.out.println("Laptop Battery Cell Count:" + laptop.battaryCellCount);
        System.out.println("Laptop Screen Size:" + laptop.screenSize);
        System.out.println("Laptop SerialNumber:" + laptop.serialNumber);
    }
}

package masala2;

import java.util.Scanner;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masala2
 * Class Name -> Masala1
 * Copyright © : 8/23/2022
 */
public class Masala1 {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        String a = scanner.nextLine();
        String b = scanner.nextLine();
        if (a.equalsIgnoreCase(b)){
            System.out.println("Bir xil");
        }else {
            System.out.println("Xar Xil");
        }
    }
}

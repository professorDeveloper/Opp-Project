package masala2;

import java.util.Scanner;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masala2
 * Class Name -> Masala3
 * Copyright © : 8/23/2022
 */
public class Masala3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        char[] charArray=a.toCharArray();
        int count =0;
        for (int i = 0; i < charArray.length; i++) {
            char unli =charArray[i];
            if (unli=='a'||unli=='e'||unli=='i'||unli=='u'||unli=='o'||unli=='A'||unli=='E'||unli=='U'||unli=='O'){
                count++;
            }
        }
        System.out.println(count);

    }


}

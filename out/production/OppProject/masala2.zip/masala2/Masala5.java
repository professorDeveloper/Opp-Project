package masala2;

import java.util.Scanner;

/**
 * Project Admin -> Husanboy Azamov
 * Package Name  -> masala2
 * Class Name -> Masala5
 * Copyright © : 8/24/2022
 */
public class Masala5 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String s = scanner.nextLine();
        String s1 = scanner.nextLine();
        if (s.toUpperCase().equals(s1.toLowerCase())){
            System.out.println("Ha");
        }else {
            System.out.println("yo`q");
        }
    }
}
